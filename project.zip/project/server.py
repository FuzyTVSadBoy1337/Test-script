from flask import Flask, render_template, url_for

app = Flask(__name__, static_folder="static", template_folder="templates")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    # Fake data để hiển thị UI
    accounts = [
        {
            "username": "Fuzy123",
            "race": "Human V3",
            "melee": "Superhuman",
            "sword": "Yoru",
            "gun": "Kabucha",
            "fruits": ["Dragon", "Dough", "Magma"]
        },
        {
            "username": "NoobPro",
            "race": "Fishman V2",
            "melee": "Dragon Talon",
            "sword": "Saddi",
            "gun": "Acidum Rifle",
            "fruits": ["Leopard", "Ice", "Flame", "Light"]
        },
        {
            "username": "TryHard",
            "race": "Mink V4",
            "melee": "Electric Claw",
            "sword": "Shisui",
            "gun": "Bazooka",
            "fruits": ["Venom", "Buddha", "Rubber"]
        },
        {
            "username": "SoloMain",
            "race": "Ghoul V3",
            "melee": "Godhuman",
            "sword": "Rengoku",
            "gun": "Musket",
            "fruits": ["Phoenix", "Dark", "Light"]
        }
    ]
    return render_template("dashboard.html", accounts=accounts)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)