function copyScript() {
  const placeholder = `-- Blox Fruits TrackStats script (placeholder)
-- Replace with your actual executor script
print("Script placeholder copied!")`;
  navigator.clipboard.writeText(placeholder).then(() => {
    alert("Script copied to clipboard!");
  }).catch(()=>{ alert("Unable to copy (browser blocked)."); });
}

function goWithLoading(evt, url){
  // Prevent default immediate navigation to show spinner
  if(evt) evt.preventDefault();
  const el = document.getElementById("loading");
  if(el) el.classList.remove("hidden");
  setTimeout(()=>{ window.location.href = url; }, 700);
}